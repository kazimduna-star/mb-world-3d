import * as THREE from 'three';
import { CONFIG } from '../config.js';
import { heightAt } from './world.js';

const sleep = ms => new Promise(r => setTimeout(r, ms));

// Светящаяся «плёнка» портала: шейдерный вихрь внутри проёма арки.
export function makeSwirl(w, h, col) {
  const a = col?.a || [.25, .35, 1], b = col?.b || [.8, .5, 1];
  const mat = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
    uniforms: { uT: { value: 0 }, uI: { value: .3 }, ca: { value: new THREE.Vector3(...a) }, cb: { value: new THREE.Vector3(...b) } },
    vertexShader: 'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: `varying vec2 vUv;uniform float uT,uI;uniform vec3 ca,cb;void main(){vec2 p=(vUv-.5)*2.;float r=length(p);if(r>1.)discard;float an=atan(p.y,p.x);
      float s1=sin(an*5.+r*9.-uT*3.)*.5+.5,s2=sin(an*3.-r*14.+uT*2.)*.5+.5;vec3 c=mix(ca,cb,s1)+s2*.3;float core=smoothstep(1.,0.,r),edge=smoothstep(1.,.82,r);
      gl_FragColor=vec4(c*(.4+core*.9)*uI,edge*(.35+.5*uI)*(.5+.5*s1));}` });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat); mesh.frustumCulled = false; let I = .3;
  return { mesh, update(t, on) { I += ((on ? 1.3 : .3) - I) * .08; mat.uniforms.uT.value = t; mat.uniforms.uI.value = I; mesh.scale.setScalar(1 + (on ? Math.sin(t * 12) * .04 : 0)); } };
}

// Телепортация без перезагрузки: затемнение, подгрузка нужной зоны, перенос той же Аэлии, сохранение.
export class Teleporter {
  constructor(g) {
    this.g = g; this.busy = false; this.fade = document.createElement('div'); this.fade.className = 'fade'; g.ui.appendChild(this.fade);
  }
  async ensure(def) {
    const z = this.g.zones, t0 = performance.now();
    if (!z.loaded.has(def.id) && !z.loading.has(def.id)) z.load(def);
    while (!z.loaded.has(def.id) && performance.now() - t0 < 90000) await sleep(100);
  }
  async go(t) {
    if (this.busy) return; this.busy = true; const { zones, player, rig, world, save } = this.g;
    this.fade.classList.add('on'); await sleep(500);
    try {
      const def = CONFIG.zones.find(z => z.id === t.zone); if (def) await this.ensure(def);
      player.pos.set(t.x, heightAt(t.x, t.z), t.z); player.vel.set(0, 0, 0); player.facing = t.facing; player.invuln = 1.5;
      rig.yaw = t.facing + Math.PI; rig.first = true; world.grassCenter.set(1e9, 1e9); save();
    } catch (e) { console.error('Ошибка телепортации', e); }
    await sleep(400); this.fade.classList.remove('on'); this.busy = false;
  }
}
