# Инвентаризация ресурсов

## Героиня Аэлия — `assets/characters/aelia.glb` (оригинал, 44,4 МБ, без изменений)
- Скелет: есть, 69 костей (риг типа Auto-Rig Pro: spine, arm/forearm/thigh/leg/foot, пальцы, twist-кости).
- Анимации: **нет ни одного клипа**. Сейчас кости двигаются процедурно (`scripts/animations.js`, класс RigPose). Настоящие клипы подхватятся автоматически по именам idle/walk/run/jump/attack/dodge/death, если добавить их в GLB.
- Геометрия: 9 мешей, 546 тыс. вершин, **972 тыс. треугольников**. Это очень тяжело для iPhone.
- Текстура: одна, JPEG 4096×4096, один материал (двусторонний, без normal map).
- Рост модели 5,19 условной единицы, масштаб 0,337 даёт около 1,75 м. Лицом к +Z.

## Nature MegaKit → `assets/environment/nature/` (68 моделей glTF + текстуры, 48 МБ)
Bush_Common(+Flowers), Clover_1-2, CommonTree_1-5, DeadTree_1-5, Fern_1, Flower_3/4 (Group, Single), Grass_Common/Wispy (Short, Tall), Mushroom_Common/Laetiporus, Pebble_Round_1-5, Pebble_Square_1-6, Petal_1-5, Pine_1-5, Plant_1/7 (+Big), RockPath_* (10), Rock_Medium_1-3, TwistedTree_1-5.

## Medieval Village MegaKit → `assets/buildings/medieval/` (используемые части, 50 МБ)
В архиве 176 моделей (стены, углы, двери, полы, крыши, лестницы, балконы, заборы, повозка и др.). Подключены 14: стены Plaster и UnevenBrick (прямые, с дверью, с окном), угол, пол, крыши 4x4/6x6, башенная крыша, повозка, ящик, забор, труба.

## Монстры (FBX, без скелета и анимаций) → `assets/monsters/{fallen,undead}/<имя>/`
Fallen: blind-seraph, broken-cherub, burning-reliquary, lucifer-avatar, the-apostate. Undead: chainwraith, necromancer, ossuary-legionary, rotwalker, the-unborn.
У каждого 4 PNG 2048×2048 (basecolor, normal, roughness, metallic). Паки готовы к риггингу на Mixamo.

## Ваши одиночные GLB (все используются)
| Файл в проекте | Что это | Где используется |
|---|---|---|
| `assets/dungeons/ancient-gateway.glb` (7,7 МБ) | мшистая каменная арка, 141 тыс. тр. | портал в открытом мире (70, -125) и обратный портал на арене |
| `assets/dungeons/water-stone-dungeon.glb` (1,7 МБ) | зал 22×47 м, 34 тыс. тр., без текстур | подземелье (вход в (-100, -95)) |
| `assets/environment/isle_of_plenty.glb` (57 МБ) | остров, 2191 меш, 259 тыс. тр. | парящий остров над северо-западом долины |
| `assets/environment/floor_low_poly.glb` | плитка 2×2 м | площадка у портала и пол арены |
| `assets/environment/icicles.glb` | кристаллы льда, 150 тыс. тр. | арена |
| `assets/environment/tree_2_5.glb`, `stylized_rock.glb` | дерево, камень | лес в долине, вход в подземелье |
| `assets/environment/meadow_patch.glb` (72 МБ, 925 тыс. тр., 4096²) | цветочный луг | только при окружении «Очень высокое» и выше |
| `assets/environment/rock_outcrop.glb` (115 МБ, 1,9 млн тр., 4096²) | каменистый участок | только при «Максимальном». Файл больше 100 МБ: для GitHub нужен Git LFS. Если не загрузите, игра работает без него |

## Не подключено
- `genshin-impact-arsenal`: 99 PNG-текстур и .blend, готовых веб-моделей нет.
- `Korvix3D_Asset_Hub...exe`: установщик Windows.

## Структура папки assets (проверена: все 103 пути из кода существуют)
```
assets/
  characters/aelia.glb
  environment/nature/*.gltf, *.bin, *.png      (Nature MegaKit, 68 моделей)
  environment/{isle_of_plenty,floor_low_poly,icicles,tree_2_5,stylized_rock,meadow_patch}.glb
  buildings/medieval/*.gltf, *.bin, *.png      (14 кусков Medieval Village + их текстуры)
  dungeons/{ancient-gateway,water-stone-dungeon}.glb
  monsters/fallen/<имя>/<имя>.fbx + textures/<имя>_{basecolor,normal,roughness,metallic}.png
  monsters/undead/<имя>/...                    (то же)
```
Файл `environment/rock_outcrop.glb` (115 МБ) в ZIP не входит: он больше лимита GitHub. Игра работает без него (он нужен только на «Максимальном»).
В корне лежит пустой `.nojekyll`, чтобы GitHub Pages отдавал файлы как есть.
