import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { CONFIG } from '../config.js';
import { heightAt, clampToBounds } from './world.js';
import { Animator } from './animations.js';

const P = CONFIG.player, WATER_BLOCK = -2.4;
const angDiff = (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };

export class Player {
  constructor(scene, world) {
    this.world = world; this.root = new THREE.Group(); this.visual = new THREE.Group(); this.root.add(this.visual); this.pos = this.root.position;
    this.vel = new THREE.Vector3(); this.facing = Math.PI; this.hp = P.maxHp; this.maxHp = P.maxHp; this.level = 1;
    this.grounded = true; this.dead = false; this.state = 'idle'; this.speed = 0; this.dodgeT = 0; this.dodgeCd = 0; this.invuln = 0; this.dodgeDir = new THREE.Vector2();
    this.animator = new Animator(this.visual);
    // ВРЕМЕННАЯ заглушка: капсула для проверки управления. Удаляется при подключении модели Аэлии.
    this.placeholder = new THREE.Group();
    const cap = new THREE.Mesh(new THREE.CapsuleGeometry(.4, .9, 4, 12), new THREE.MeshStandardMaterial({ color: 0x8b6cff, emissive: 0x2a1a66, roughness: .6 })); cap.position.y = .85; cap.castShadow = true;
    const nose = new THREE.Mesh(new THREE.BoxGeometry(.2, .2, .3), new THREE.MeshStandardMaterial({ color: 0xffffff })); nose.position.set(0, 1.25, .42);
    this.placeholder.add(cap, nose); this.visual.add(this.placeholder); scene.add(this.root);
    this.pos.set(0, heightAt(0, 6), 6);
    this.spawn = this.pos.clone(); this.inv = { coins: 0, stones: 0 };
  }
  // Подключение модели Аэлии: оригинальный файл, без изменения геометрии и текстур.
  async loadModel(url, onProgress) {
    const g = await new GLTFLoader().loadAsync(url, e => e.total && onProgress?.(e.loaded / e.total)); this.visual.remove(this.placeholder);
    g.scene.scale.setScalar(P.modelScale || 1); g.scene.traverse(o => { if (o.isMesh) o.frustumCulled = false; }); this.visual.add(g.scene); this.model = g.scene; if (this.lastGfx) this.applyGfx(...this.lastGfx);
    this.animator.setModel(g.scene, g.animations); console.info('Модель героини загружена. Нет клипов:', this.animator.missing);
  }
  // Графика персонажа: только тень и фильтрация текстуры. Геометрия и разрешение текстур не меняются.
  applyGfx(r, maxA) { this.lastGfx = [r, maxA]; this.model?.traverse(o => { if (o.isMesh) { o.castShadow = r.charShadow; const m = o.material; if (m?.map) m.map.anisotropy = Math.min(r.aniso, maxA); } }); }
  respawn() { this.hp = this.maxHp; this.dead = false; this.pos.copy(this.spawn); this.vel.set(0, 0, 0); this.invuln = 2; }
  get dodgeFrac() { return this.dodgeCd / .8; }
  jump() { if (this.grounded && !this.dead && this.dodgeT <= 0) { this.vel.y = P.jumpV; this.grounded = false; } }
  dodge(move, camYaw) {
    if (this.dodgeCd > 0 || this.dead) return;
    const s = Math.sin(camYaw), c = Math.cos(camYaw), l = Math.hypot(move.x, move.y);
    if (l > .1) this.dodgeDir.set((c * move.x - s * move.y) / l, (-s * move.x - c * move.y) / l); else this.dodgeDir.set(Math.sin(this.facing), Math.cos(this.facing));
    this.facing = Math.atan2(this.dodgeDir.x, this.dodgeDir.y); this.dodgeT = .32; this.dodgeCd = .8; this.invuln = .4;
  }
  damage(n) { if (this.invuln > 0 || this.dead) return; this.hp = Math.max(0, this.hp - n); if (!this.hp) this.dead = true; }
  update(dt, inp, camYaw, combat, autoRun, runToggle) {
    this.dodgeCd = Math.max(0, this.dodgeCd - dt); this.invuln -= dt; this.dodgeT -= dt;
    const mx = inp.move.x, my = inp.move.y, mag = Math.min(1, Math.hypot(mx, my)), s = Math.sin(camYaw), c = Math.cos(camYaw);
    let tx = 0, tz = 0, running = false;
    if (!this.dead && mag > .08) {
      running = runToggle || (autoRun && mag > .85);
      const sp = (running ? P.run : P.walk) * (running ? 1 : Math.max(.45, Math.min(1, mag / .85))) * combat.moveScale;
      tx = (c * mx - s * my) / mag * sp; tz = (-s * mx - c * my) / mag * sp;
      if (heightAt(this.pos.x, this.pos.z) < -1.5) { tx *= .6; tz *= .6; }
    }
    if (this.dodgeT > 0) { tx = this.dodgeDir.x * 14; tz = this.dodgeDir.y * 14; this.vel.x = tx; this.vel.z = tz; }
    else { const k = Math.min(1, dt * (this.grounded ? 14 : 4)); this.vel.x += (tx - this.vel.x) * k; this.vel.z += (tz - this.vel.z) * k; }
    this._move(this.vel.x * dt, this.vel.z * dt);
    this.vel.y -= P.gravity * dt; this.pos.y += this.vel.y * dt;
    const g = heightAt(this.pos.x, this.pos.z);
    if (this.pos.y <= g) { this.pos.y = g; this.vel.y = 0; this.grounded = true; } else if (this.pos.y > g + .08) this.grounded = false;
    this.speed = Math.hypot(this.vel.x, this.vel.z);
    if (combat.faceTo !== null) this.facing += angDiff(this.facing, combat.faceTo) * Math.min(1, dt * 20);
    else if (this.speed > .5 && this.dodgeT <= 0) this.facing += angDiff(this.facing, Math.atan2(this.vel.x, this.vel.z)) * Math.min(1, dt * P.turn);
    this.root.rotation.y = this.facing;
    this.state = this.dead ? 'death' : this.dodgeT > 0 ? 'dodge' : combat.cur ? 'attack' : !this.grounded ? 'jump' : this.speed > P.walk + 1 ? 'run' : this.speed > .5 ? 'walk' : 'idle';
    this.running = running; this.animator.update(dt, { state: this.state, attackP: combat.attackP });
  }
  _move(dx, dz) {
    const w = this.world; let nx = this.pos.x + dx, nz = this.pos.z + dz;
    if (heightAt(nx, nz) < WATER_BLOCK) { if (heightAt(nx, this.pos.z) >= WATER_BLOCK) nz = this.pos.z; else if (heightAt(this.pos.x, nz) >= WATER_BLOCK) nx = this.pos.x; else { nx = this.pos.x; nz = this.pos.z; } }
    for (const c of w.colliders) {
      if (c.active === false || this.pos.y > heightAt(c.x, c.z) + c.h) continue;
      const ox = nx - c.x, oz = nz - c.z, d = Math.hypot(ox, oz), min = c.r + P.radius;
      if (d < min && d > 1e-4) { nx = c.x + ox / d * min; nz = c.z + oz / d * min; }
    }
    [this.pos.x, this.pos.z] = clampToBounds(nx, nz);
  }
}
