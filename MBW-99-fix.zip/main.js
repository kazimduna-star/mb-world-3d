import * as THREE from 'three';
import { CONFIG } from './config.js';
import * as Settings from './scripts/settings.js';
import { World, heightAt } from './scripts/world.js';
import { ZoneManager } from './scripts/zones.js';
import { Player } from './scripts/player.js';
import { CameraRig } from './scripts/camera.js';
import { Combat } from './scripts/combat.js';
import { Quests } from './scripts/quests.js';
import { Input } from './scripts/input.js';
import { Teleporter } from './scripts/portal.js';
import { Hud } from './ui/hud.js';
import { openQuests } from './ui/quests.js';
import { Menus } from './ui/menu.js';
import { openSettings } from './ui/settings.js';

const frame = () => new Promise(r => requestAnimationFrame(() => r()));
const ui = document.getElementById('ui'), canvas = document.getElementById('game');
let running = false, time = 0, settingsOpen = false;

// Защита от циклической перезагрузки: если прошлая загрузка не дошла до меню (Safari закрыл страницу из-за нехватки памяти), включается облегчённый режим.
let safe = false;
try { safe = !!sessionStorage.getItem('mbw3d.booting'); sessionStorage.setItem('mbw3d.booting', '1'); } catch { /* нет sessionStorage */ }
Settings.load();
if (safe) Settings.setPreset(0);
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.outputColorSpace = THREE.SRGBColorSpace;
const camera = new THREE.PerspectiveCamera(CONFIG.camera.fov, innerWidth / innerHeight, .1, 300), scene = new THREE.Scene();

const menus = new Menus(ui, {
  start: () => { menus.hideMain(); setRunning(true); if (safe) hud.toast('Облегчённый режим: прошлая загрузка прервалась из-за нехватки памяти. Графика сброшена на «Низкое». Тяжёлые модели и монстры отключены.', 7000); },
  resume: () => setRunning(true),
  settings: () => { if (settingsOpen) return; settingsOpen = true; openSettings(ui, { input, onClose: () => { settingsOpen = false; } }); }
});
let pct = 0;
const progress = (p, t) => { pct = Math.max(pct, p); menus.setProgress(pct, t); };   // прогресс не откатывается назад
const fail = msg => { console.error(msg); menus.lbl.textContent = 'Ошибка загрузки: ' + msg; };
addEventListener('error', e => fail(e.message)); addEventListener('unhandledrejection', e => fail(e.reason?.message || String(e.reason)));
const input = new Input(ui);
const hud = new Hud(ui, {
  pause: () => setRunning(false),
  quests: () => { if (settingsOpen || !running) return; settingsOpen = true; openQuests(ui, { quests, onClose: () => { settingsOpen = false; } }); },
  view: () => Settings.setCtl('camMode', Settings.state.ctl.camMode === 'first' ? 'third' : 'first')
});
let world, zones, player, rig, combat, quests, tele;

function setRunning(on) {
  const started = running || on; running = on; input.setEnabled(on); hud.show(on); menus.showPause(!on && started);
}

function applyGfx() {
  const r = Settings.resolved(); renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, r.dpr)); renderer.setSize(innerWidth, innerHeight, false);
  zones.maxAniso = renderer.capabilities.getMaxAnisotropy(); world.applyGfx(r); zones.applyGfx(r); player?.applyGfx(r, zones.maxAniso);
}

(async function boot() {
  progress(5, 'Подготовка...'); await frame();
  world = new World(scene, camera, renderer); zones = new ZoneManager(scene, world); zones.safe = safe; progress(15, 'Создание мира...'); await frame();
  applyGfx(); await zones.load(CONFIG.zones[0], f => progress(15 + f * 55, 'Загрузка мира...')); progress(70, 'Загрузка героини...'); await frame();
  player = new Player(scene, world);
  try { await player.loadModel(CONFIG.player.modelUrl, f => progress(70 + f * 25, 'Загрузка героини...')); } catch (e) { console.error('Модель Аэлии не загружена, используется капсула', e); }
  world.player = player; world.onPlayerHit = n => hud.damage(player.pos.x, player.pos.y + 2, player.pos.z, n, camera); player.applyGfx(Settings.resolved(), zones.maxAniso);
  loadSave(); rig = new CameraRig(camera, world); rig.yaw = savedYaw; tele = new Teleporter({ zones, player, rig, world, save, ui }); quests = new Quests(world, hud, player); quests.restore(savedQuests); combat = new Combat(scene, world, player, hud, camera);
  Settings.onChange(() => { applyGfx(); input.applyLayout(); });
  scene.updateMatrixWorld(); renderer.compile(scene, camera); progress(100, 'Готово'); await frame();
  try { sessionStorage.removeItem('mbw3d.booting'); } catch { /* нет sessionStorage */ }
  menus.showMain(); loop();
})().catch(e => fail(e.message));

addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight, false); });
document.addEventListener('visibilitychange', () => { if (document.hidden && running) { save(); setRunning(false); } });

const clock = new THREE.Clock();
function loop() {
  requestAnimationFrame(loop); const dt = Math.min(clock.getDelta(), .05); time += dt;
  if (running && !settingsOpen) sim(dt); else if (!running) { rig.idle(dt, player); world.update(dt, time, player.pos); zones.update(dt, time, player.pos); }
  renderer.render(scene, camera);
}

function sim(dt) {
  const inp = input.poll(), ctl = Settings.state.ctl;
  for (const a of inp.actions) {
    if (a === 'jump') player.jump(); else if (a === 'dodge') player.dodge(inp.move, rig.yaw);
    else if (a === 'attack') combat.request('light'); else if (a === 'heavy') combat.request('heavy'); else if (a === 'skill') combat.request('skill');
    else if (a === 'interact' && near) near.onUse({ hud, world, player, tele, quests });
  }
  if (input.isHeld('attack')) combat.request('light');
  combat.update(dt); player.update(dt, inp, rig.yaw, combat, ctl.autoRun, input.runToggle); rig.update(dt, player, input, ctl.camSens, ctl.camMode); player.visual.visible = ctl.camMode !== 'first';
  world.update(dt, time, player.pos); zones.update(dt, time, player.pos); quests.update(player.pos);
  near = null; let bd = 1e9; for (const i of world.interactables) { if (i.when && !i.when()) continue; const d = Math.hypot(i.x - player.pos.x, i.z - player.pos.z); if (d < i.r && d < bd) { bd = d; near = i; } }
  input.setInteract(near ? near.label : null); input.setCooldown('skill', combat.cdFrac('skill')); input.setCooldown('heavy', combat.cdFrac('heavy')); input.setCooldown('dodge', player.dodgeFrac);
  if (player.dead) { if ((deadT += dt) > 3) { player.respawn(); deadT = 0; hud.toast('Вы возродились'); } } else deadT = 0;
  if ((saveT += dt) > 5) { saveT = 0; save(); }
  hud.update(dt, { player, quest: quests, yaw: rig.yaw, zone: zones.currentZone(player.pos)?.name });
}
let near = null, deadT = 0, saveT = 0, savedYaw = 0, savedQuests = null;
const SAVE = 'mbw3d.save.v1';
function loadSave() {   // единая система координат мира: сохраняются x, z и вращение камеры
  try { const s = JSON.parse(localStorage.getItem(SAVE)); if (s && isFinite(s.x) && isFinite(s.z)) { player.pos.set(s.x, heightAt(s.x, s.z), s.z); player.spawn.set(s.x, heightAt(s.x, s.z), s.z); savedYaw = s.yaw || 0; if (s.inv) Object.assign(player.inv, s.inv); if (s.flags) Object.assign(world.flags, s.flags); savedQuests = s.quests || null; } } catch { /* нет сохранения */ }
}
function save() { if (Math.abs(player.pos.x) > 300 || Math.abs(player.pos.z) > 300) return; try { localStorage.setItem(SAVE, JSON.stringify({ x: +player.pos.x.toFixed(2), z: +player.pos.z.toFixed(2), yaw: +rig.yaw.toFixed(2), inv: player.inv, flags: world.flags, quests: quests?.serialize() })); } catch { /* приватный режим */ } }
