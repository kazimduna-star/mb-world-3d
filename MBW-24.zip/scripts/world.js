import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { CONFIG } from '../config.js';

const sm = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
export const hash = (i, j) => { const s = Math.sin(i * 127.1 + j * 311.7) * 43758.5453; return s - Math.floor(s); };

// Аналитическая высота рельефа: используется и для меша, и для физики, и для размещения объектов.
const baseH = (x, z) => {
  const d = Math.hypot(x, z);
  let h = Math.sin(x * .02) * 3 + Math.cos(z * .025) * 3 + Math.sin((x + z) * .045) * 1.6 + Math.sin(x * .11) * Math.cos(z * .09) * .5;
  h *= .15 + .85 * sm(0, 60, d);
  h += sm(120, 200, d) * (20 + Math.sin(x * .05) * 6 + Math.cos(z * .06) * 5);
  h -= 7 * Math.exp(-(((x + 60) ** 2 + (z - 50) ** 2) / 784));
  return h;
};
const PADS = CONFIG.pads.map(p => ({ ...p, h: p.h ?? Math.max(baseH(p.x, p.z), .3) }));
export function heightAt(x, z) {
  let h = baseH(x, z);
  for (const p of PADS) { const d = Math.hypot(x - p.x, z - p.z); if (d < p.r + 14) { const t = 1 - sm(p.r, p.r + 14, d); h = h * (1 - t) + p.h * t; } }
  return h;
}

const HORIZON = 0xcdb6ee;
const MAX_GRASS = 18000;

export class World {
  constructor(scene, camera, renderer) {
    this.scene = scene; this.camera = camera; this.renderer = renderer;
    this.colliders = []; this.targets = []; this.interactables = []; this.flags = {};
    this.uTime = { value: 0 }; this.gfx = null; this.grassCenter = new THREE.Vector2(1e9, 1e9);
    scene.fog = new THREE.FogExp2(HORIZON, .006);
    this._sky(); this._lights(); this._terrain(); this._water(); this._grass(); this._fireflies();
  }
  _sky() {
    const m = new THREE.ShaderMaterial({ side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false,
      uniforms: { top: { value: new THREE.Color(0x4a3fa0) }, hor: { value: new THREE.Color(HORIZON) }, sun: { value: new THREE.Vector3(-.4, .8, .5).normalize() } },
      vertexShader: 'varying vec3 v;void main(){v=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
      fragmentShader: 'uniform vec3 top,hor,sun;varying vec3 v;void main(){float k=smoothstep(0.,.55,v.y);vec3 c=mix(hor,top,k);c+=vec3(1.,.8,.6)*pow(max(dot(v,sun),0.),48.)*.8;gl_FragColor=vec4(c,1.);}' });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(150, 24, 12), m); this.sky.renderOrder = -1000; this.sky.frustumCulled = false; this.scene.add(this.sky);
  }
  _lights() {
    this.hemi = new THREE.HemisphereLight(0xcfc2ff, 0x4a6a3a, .9); this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xffe3c4, 1); this.sunDir = new THREE.Vector3(-.4, .8, .5).normalize();
    const c = this.sun.shadow.camera; c.left = c.bottom = -40; c.right = c.top = 40; c.near = .5; c.far = 220;
    this.sun.shadow.bias = -.0005; this.sun.shadow.normalBias = .05;
    this.scene.add(this.sun, this.sun.target);
    this.glow = new THREE.PointLight(0xa58bff, 0, 10, 2); this.scene.add(this.glow);
  }
  _terrain() {
    const g = new THREE.PlaneGeometry(400, 400, 160, 160); g.rotateX(-Math.PI / 2);
    const p = g.attributes.position, col = new Float32Array(p.count * 3), c = new THREE.Color(), t = new THREE.Color();
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), z = p.getZ(i), h = heightAt(x, z); p.setY(i, h);
      const sl = Math.hypot(heightAt(x + 1.5, z) - h, heightAt(x, z + 1.5) - h) / 1.5;
      c.set(0x5f9e4a).lerp(t.set(0x8cba5c), .5 + .5 * Math.sin(x * .13 + z * .09));
      if (h < -.7) c.set(0xcfc08e); else if (h < -.2) c.lerp(t.set(0xcfc08e), .6);
      if (sl > .8 || h > 16) c.lerp(t.set(0x7d7a8c), Math.min(1, Math.max(sl - .5, (h - 16) / 4)));
      if (h > 26) c.lerp(t.set(0xeeeaf8), Math.min(1, (h - 26) / 4));
      col.set([c.r, c.g, c.b], i * 3);
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.computeVertexNormals();
    this.terrain = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true })); this.terrain.receiveShadow = true; this.scene.add(this.terrain);
  }
  _water() {
    this.water = new THREE.Mesh(new THREE.PlaneGeometry(150, 150, 1, 1).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial());
    this.water.position.set(-60, CONFIG.waterY, 50); this.scene.add(this.water); this.waterSeg = -1;
  }
  _setWater(seg) {
    if (seg === this.waterSeg) return; this.waterSeg = seg; this.water.geometry.dispose(); this.water.material.dispose();
    this.water.geometry = new THREE.PlaneGeometry(150, 150, Math.max(1, seg), Math.max(1, seg)).rotateX(-Math.PI / 2);
    if (seg === 0) { this.water.material = new THREE.MeshBasicMaterial({ color: 0x4a86d6, transparent: true, opacity: .8 }); return; }
    const m = new THREE.MeshPhongMaterial({ color: 0x3a7bd5, transparent: true, opacity: .78, shininess: 90, specular: 0xffffff });
    m.onBeforeCompile = s => {
      s.uniforms.uTime = this.uTime;
      s.vertexShader = s.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\ntransformed.y+=sin(position.x*.35+uTime*1.2)*.07+cos(position.z*.28+uTime)*.07;');
    };
    this.water.material = m;
  }
  _grass() {
    const a = new THREE.PlaneGeometry(.16, .8, 1, 2).translate(0, .4, 0), b = a.clone().rotateY(Math.PI / 2);
    const g = mergeGeometries([a, b]), p = g.attributes.position, col = new Float32Array(p.count * 3), d = new THREE.Color(0x2f6a35), l = new THREE.Color(0x9ad468), c = new THREE.Color();
    for (let i = 0; i < p.count; i++) { const t = p.getY(i) / .8; p.setX(i, p.getX(i) * (1 - t * .85)); p.setZ(i, p.getZ(i) * (1 - t * .85)); c.copy(d).lerp(l, t); col.set([c.r, c.g, c.b], i * 3); }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const m = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
    m.onBeforeCompile = s => {
      s.uniforms.uTime = this.uTime;
      s.vertexShader = s.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\ntransformed.x+=sin(uTime*1.7+instanceMatrix[3].x*.5+instanceMatrix[3].z*.4)*.14*position.y;');
    };
    this.grass = new THREE.InstancedMesh(g, m, MAX_GRASS); this.grass.count = 0; this.grass.frustumCulled = false; this.grass.receiveShadow = true; this.scene.add(this.grass);
  }
  _regenGrass(cx, cz) {
    const { r, s } = this.gfx.grass; this.grassCenter.set(cx, cz);
    if (!r) { this.grass.count = 0; return; }
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), sc = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0); let n = 0;
    for (let i = Math.floor((cx - r) / s); i <= Math.floor((cx + r) / s); i++) for (let j = Math.floor((cz - r) / s); j <= Math.floor((cz + r) / s); j++) {
      const hx = hash(i, j), x = (i + hx) * s, z = (j + hash(j + 17, i - 5)) * s;
      if ((x - cx) ** 2 + (z - cz) ** 2 > r * r || n >= MAX_GRASS) continue;
      const y = heightAt(x, z); if (y < -.9 || y > 15) continue;
      const k = .7 + hash(i * 3, j * 7) * .9; p.set(x, y, z); q.setFromAxisAngle(up, hash(i + 9, j + 3) * 6.28); sc.set(k, k * (.8 + hx * .6), k);
      m.compose(p, q, sc); this.grass.setMatrixAt(n++, m);
    }
    this.grass.count = n; this.grass.instanceMatrix.needsUpdate = true;
  }
  _fireflies() {
    const cv = document.createElement('canvas'); cv.width = cv.height = 32; const x = cv.getContext('2d'), gr = x.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(.3, 'rgba(255,240,170,.8)'); gr.addColorStop(1, 'rgba(255,240,170,0)'); x.fillStyle = gr; x.fillRect(0, 0, 32, 32);
    const N = 400, g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(N * 3), 3));
    this.ffSeed = Array.from({ length: N }, (_, i) => [hash(i, 1) * 50, hash(i, 2) * 50, hash(i, 3) * 6.28]);
    this.ff = new THREE.Points(g, new THREE.PointsMaterial({ size: .35, map: new THREE.CanvasTexture(cv), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, color: 0xfff0b0 }));
    this.ff.frustumCulled = false; this.scene.add(this.ff);
  }
  applyGfx(r) {
    this.gfx = r; const cam = this.camera; cam.far = r.draw.far; cam.updateProjectionMatrix(); this.scene.fog.density = r.draw.fog;
    this.renderer.toneMapping = r.light.tone ? THREE.ACESFilmicToneMapping : THREE.NoToneMapping;
    this.hemi.intensity = r.light.hemi; this.sun.intensity = r.light.sun; this.glow.intensity = r.light.glow;
    this.sun.castShadow = r.shadow > 0;
    if (r.shadow > 0 && this.sun.shadow.mapSize.x !== r.shadow) { this.sun.shadow.map?.dispose(); this.sun.shadow.map = null; this.sun.shadow.mapSize.set(r.shadow, r.shadow); }
    this._setWater(r.waterSeg); this.ff.geometry.setDrawRange(0, r.fx); this.ff.visible = r.fx > 0;
    this.grassCenter.set(1e9, 1e9);
  }
  update(dt, t, pp) {
    this.uTime.value = t; this.sky.position.copy(this.camera.position);
    this.sun.position.copy(pp).addScaledVector(this.sunDir, 90); this.sun.target.position.copy(pp);
    this.glow.position.set(pp.x, pp.y + 1.6, pp.z);
    if (this.grassCenter.distanceTo(new THREE.Vector2(pp.x, pp.z)) > 3) this._regenGrass(pp.x, pp.z);
    const n = this.gfx.fx; if (n) {
      const a = this.ff.geometry.attributes.position;
      for (let i = 0; i < n; i++) {
        const s = this.ffSeed[i], x = pp.x + ((s[0] - pp.x) % 50 + 75) % 50 - 25 + Math.sin(t * .7 + s[2]) * 1.2, z = pp.z + ((s[1] - pp.z) % 50 + 75) % 50 - 25 + Math.cos(t * .6 + s[2]) * 1.2;
        a.setXYZ(i, x, Math.max(heightAt(x, z), CONFIG.waterY) + .9 + Math.sin(t + s[2]) * .5, z);
      }
      a.needsUpdate = true;
    }
  }
}

// Ограничение движения: внутри арены/подземелья — их границы, в открытом мире — края карты.
export const areaFor = (x, z) => (CONFIG.areas || []).find(a => Math.hypot(x - a.cx, z - a.cz) < 150) || null;
export function clampToArea(a, x, z, m = 0) {
  if (a.r) { const dx = x - a.cx, dz = z - a.cz, d = Math.hypot(dx, dz), R = a.r - m; return d > R ? [a.cx + dx / d * R, a.cz + dz / d * R] : [x, z]; }
  const [x0, x1, z0, z1] = a.rect; return [Math.min(a.cx + x1 - m, Math.max(a.cx + x0 + m, x)), Math.min(a.cz + z1 - m, Math.max(a.cz + z0 + m, z))];
}
export function clampToBounds(x, z) { const a = areaFor(x, z), b = CONFIG.bounds; return a ? clampToArea(a, x, z) : [Math.max(-b, Math.min(b, x)), Math.max(-b, Math.min(b, z))]; }
