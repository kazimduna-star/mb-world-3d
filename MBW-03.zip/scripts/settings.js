import { GFX, DEFAULT_CONTROLS } from '../config.js';
const KEY = 'mbw3d.settings.v1';
const listeners = new Set();
export const state = {
  gfx: { preset: 1, grass: 1, trees: 1, textures: 1, water: 1, shadows: 1, lighting: 1, draw: 1, environment: 1, effects: 1, resolution: 1, character: 1 },
  ctl: structuredClone(DEFAULT_CONTROLS)
};
const lvl = l => ({ grass: l, trees: l, textures: l, water: l, shadows: l, lighting: l, draw: l, environment: l, effects: l, resolution: l, character: l });
export function load() {
  try { const s = JSON.parse(localStorage.getItem(KEY)); if (s) { Object.assign(state.gfx, s.gfx); Object.assign(state.ctl, s.ctl); } } catch { /* первый запуск */ }
}
function emit() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* приватный режим */ } listeners.forEach(f => f(state)); }
export const onChange = f => listeners.add(f);
export const setPreset = l => { Object.assign(state.gfx, lvl(l), { preset: l }); emit(); };
export const setGfx = (k, l) => { state.gfx[k] = l; state.gfx.preset = 'custom'; emit(); };
export const setCtl = (k, v) => { state.ctl[k] = v; emit(); };
export const setLayout = (id, pos) => { state.ctl.layout[id] = pos; emit(); };
export const resetControls = () => { state.ctl = structuredClone(DEFAULT_CONTROLS); emit(); };
export function resolved() {
  const g = state.gfx;
  return { grass: GFX.grass[g.grass], trees: GFX.trees[g.trees], env: GFX.environment[g.environment], aniso: GFX.textures[g.textures],
    waterSeg: GFX.water[g.water], shadow: GFX.shadows[g.shadows], light: GFX.lighting[g.lighting], draw: GFX.draw[g.draw],
    fx: GFX.effects[g.effects], dpr: GFX.resolution[g.resolution], charShadow: g.character >= 2 };
}
